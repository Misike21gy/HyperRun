<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "HyperRun";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "DB hiba"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$request = is_array($data) ? $data : $_POST;

$email = $request['email'] ?? '';
$passw = $request['password'] ?? '';

// ===== Regisztráció =====
if (isset($request['register'])) {
    $username = $request['username'] ?? '';

    if ($email === '' || $passw === '' || $username === '') {
        echo json_encode(["success" => false, "message" => "Minden mező kötelező"]);
        exit;
    }

    $check = $conn->prepare("SELECT * FROM Felhasznalo WHERE email = ?");
    if (!$check) {
        echo json_encode(["success" => false, "message" => "Lekérdezési hiba"]);
        exit;
    }
    $check->bind_param("s", $email);
    $check->execute();
    $res = $check->get_result();

    if ($res->num_rows > 0) {
        echo json_encode(["success" => false, "message" => "Email már létezik"]);
        exit;
    }

    $insert = $conn->prepare("INSERT INTO Felhasznalo (felhasznalo, email, jelszo) VALUES (?, ?, ?)");
    if (!$insert) {
        echo json_encode(["success" => false, "message" => "Insert előkészítési hiba"]);
        exit;
    }
    $insert->bind_param("sss", $username, $email, $passw);

    if ($insert->execute()) {
        echo json_encode(["success" => true, "message" => "Sikeres regisztráció"]);
    } else {
        echo json_encode(["success" => false, "message" => "Insert hiba"]);
    }
    exit;
}

// ===== Bejelentkezés =====
if ($email === '' || $passw === '') {
    echo json_encode(["success" => false, "message" => "Hiányzó adatok"]);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM Felhasznalo WHERE email = ?");
if (!$stmt) {
    echo json_encode(["success" => false, "message" => "Lekérdezési hiba"]);
    exit;
}
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Nincs ilyen felhasználó"]);
    exit;
}

$userRow = $result->fetch_assoc();

if ($passw !== $userRow['jelszo']) {
    echo json_encode(["success" => false, "message" => "Hibás jelszó"]);
    exit;
}

echo json_encode(["success" => true, "message" => "Sikeres bejelentkezés"]);