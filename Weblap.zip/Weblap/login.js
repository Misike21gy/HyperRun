let authInProgress = false;
function sendAuthRequest(isRegister = false) {
    const emailInput = isRegister
        ? document.getElementById("regEmail")
        : document.getElementById("loginEmail");

    const passInput = isRegister
        ? document.getElementById("regPass")
        : document.getElementById("loginPass");

    const error = isRegister
        ? document.getElementById("regError")
        : document.getElementById("loginError");

    if (!emailInput || !passInput) {
        console.error("Hiányzó input mező:", {
            isRegister,
            emailInputFound: !!emailInput,
            passInputFound: !!passInput
        });
        if (error) {
            error.textContent = isRegister
                ? "Hiányoznak a regisztrációs mezők."
                : "Hiányoznak a bejelentkezési mezők.";
        }
        return;
    }

    const email = emailInput.value.trim();
    if (authInProgress) {
        console.warn("Kérés már folyamatban, duplikált kattintás blokkolva");
        return;
    }
    const password = passInput.value;

    let username = "";
    let password2 = password;

    if (isRegister) {
        const usernameInput = document.getElementById("regUser");
        const password2Input = document.getElementById("regPass2");

        username = usernameInput ? usernameInput.value.trim() : "";
        password2 = password2Input ? password2Input.value : password;

        if (username === "") {
            if (error) error.textContent = "A felhasználónév megadása kötelező.";
            return;
        }

        if (password !== password2) {
            if (error) error.textContent = "A két jelszó nem egyezik!";
            return;
        }
    }

    if (error) error.textContent = "";
    authInProgress = true;

    const body = isRegister
        ? `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}&username=${encodeURIComponent(username)}&register=1`
        : `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`;

    console.log("Küldött adatok:", {
        email,
        password,
        isRegister,
        url: "/Weblap/php/login.php"
    });

    fetch("/Weblap/php/login.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body
    })
        .then(async response => {
            const text = await response.text();
            console.log("HTTP státusz:", response.status);
            console.log("RAW válasz:", text);

            if (!response.ok) {
                throw new Error(`HTTP hiba: ${response.status}`);
            }

            try {
                return JSON.parse(text);
            } catch (e) {
                console.error("Nem JSON válasz érkezett:", text);
                throw new Error("A szerver nem JSON választ adott.");
            }
        })
        .then(data => {
            console.log(isRegister ? "SIGNUP RESPONSE:" : "LOGIN RESPONSE:", data);

            if (data.success === true) {
                localStorage.setItem("loggedIn", "true");

                if (isRegister) {
                    alert("Sikeres regisztráció! Most már bejelentkezhetsz.");
                    if (typeof switchToLogin === "function") {
                        switchToLogin();
                    } else {
                        window.location.href = "/Weblap/login.html";
                    }
                } else {
                    window.location.href = "/Weblap/hyperrun.html";
                }
            } else if (error) {
                error.textContent = data.message || (isRegister
                    ? "Sikertelen regisztráció."
                    : "Hibás belépés.");
            }
        })
        .catch(err => {
            if (error) {
                error.textContent = err.message || "Szerverhiba történt.";
            }
            console.error("Fetch hiba részletei:", err);
        })
        .finally(() => {
            authInProgress = false;
        });
}

function login() {
    sendAuthRequest(false);
}

function signup() {
    sendAuthRequest(true);
}

function registerUser() {
    sendAuthRequest(true);
}

document.addEventListener("DOMContentLoaded", () => {
    const loginBtn = document.getElementById("loginBtn");
    const registerBtn =
        document.getElementById("registerBtn") ||
        document.querySelector("button[onclick='registerUser()']");

    const loginEmail = document.getElementById("loginEmail");
    const loginPass = document.getElementById("loginPass");
    const regUser = document.getElementById("regUser");
    const regEmail = document.getElementById("regEmail");
    const regPass = document.getElementById("regPass");
    const regPass2 = document.getElementById("regPass2");

    console.log("DOMContentLoaded lefutott");
    console.log("loginBtn:", loginBtn);
    console.log("registerBtn:", registerBtn);

    if (loginBtn) {
        loginBtn.addEventListener("click", (e) => {
            e.preventDefault();
            console.log("Login gomb megnyomva");
            login();
        });
    }

    if (registerBtn) {
        registerBtn.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log("Regisztráció gomb megnyomva");
            registerUser();
        });
    }

    [loginEmail, loginPass].forEach(input => {
        if (!input) return;
        input.addEventListener("keydown", (e) => {
            if (e.key === "Enter") {
                e.preventDefault();
                login();
            }
        });
    });

    [regUser, regEmail, regPass, regPass2].forEach(input => {
        if (!input) return;
        input.addEventListener("keydown", (e) => {
            if (e.key === "Enter") {
                e.preventDefault();
                registerUser();
            }
        });
    });
});