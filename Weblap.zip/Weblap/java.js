var info = [];
info['egy']="Ez a karakter gyorsaságáról és határozottságáról ismert, mindig előre tör és nem riad vissza az akadályoktól. Megjelenése modern és energikus, ami jól tükrözi versengő természetét.";
info['ketto']="Ez a karakter lendületes és játékos, gyakran kockázatot vállal a győzelem érdekében. Külső megjelenése színes és figyelemfelkeltő, ami jól illik dinamikus személyiségéhez.";
info['harom']="Egy ravasz és taktikus szereplő, aki inkább észre, mint erőre támaszkodik a pályák során. Stílusa különleges és kissé titokzatos, ami kiemeli a többi karakter közül.";

function mutat(melyik)
{
    document.getElementById('lapozo').innerHTML=info[melyik];
}

function kiir(melyik)
{
    document.write(info[melyik]);
}
function pucol()
{
    document.getElementById('lapozo').innerHTML="Ha kíváncsi valamelyik karakter történetére, akkor mozzgasd az egérkurzort a megfelelő listaelem fölé!";
}

function visszajelzesKuld() {
  const uzenet = document.getElementById("uzenet").value;
  if (uzenet.trim() === "") return;

  const li = document.createElement("li");
  li.innerText = uzenet;
  document.getElementById("velemenyek").prepend(li);

  document.getElementById("uzenet").value = "";
}


function temaValtas() {
  document.body.classList.toggle("vilagos");
}
document.addEventListener("DOMContentLoaded", () => {

  const temaGomb = document.getElementById("tema");
  if (temaGomb) {
    temaGomb.addEventListener("click", temaValtas);
  }
});

function logout() {
    localStorage.removeItem("loggedIn");
    localStorage.removeItem("userEmail");
    window.location.href = "login.html";
  }
if (localStorage.getItem("loggedIn") !== "true") {
    window.location.href = "login.html";
  }
