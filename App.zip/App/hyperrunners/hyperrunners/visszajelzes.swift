import SwiftUI

struct Visszajelzes: View {
    
    @Environment(\.openURL) private var openURL
    @AppStorage("username") private var taroltUsername: String = ""
    
    private let feedbackEmail = "support@hyperrunners.com"
    private var subject: String { "Visszajelzés - \(taroltUsername)" }
    
    var body: some View {
        VStack(spacing: 16) {
            Text("Visszajelzés")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.primary)
                .padding(.bottom, 24)
            
            Button(action: {
                openEmail()
            }) {
                Label("Ugrás az email app-ba", systemImage: "envelope")
                    .foregroundStyle(.white)
                    .frame(width: 225, height: 50)
                    .background(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                            .fill(Color(.blue))
                    )
            }
            .padding(.bottom, 15)
            
            Text("Figyelem!\nA gomb az Ön alapértelmezett email appját nyitja meg.")
                .foregroundStyle(.red)
            
        }
        .padding()
    }
    
    private func openEmail() {
        guard let url = composeMailtoURL(to: feedbackEmail, subject: subject) else { return }
        openURL(url)
    }
    
    private func composeMailtoURL(to: String, subject: String) -> URL? {
        var components = URLComponents()
        components.scheme = "mailto"
        components.path = to
        var items: [URLQueryItem] = []
        if !subject.isEmpty {
            items.append(URLQueryItem(name: "subject", value: subject))
        }
        components.queryItems = items.isEmpty ? nil : items
        return components.url
    }
    
}

#Preview {
    Visszajelzes()
}
