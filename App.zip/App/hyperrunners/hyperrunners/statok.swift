import SwiftUI

struct statok: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                Text("Itt fognak megjelenni a statisztikák és a rangsor!")
                Text("Hamarosan...")
                    .foregroundStyle(.secondary)
            }
            .padding()
            .navigationTitle("Statisztikák")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark")
                    }
                    .accessibilityLabel("Bezárás")
                }
            }
        }
    }
}

#Preview{
    NavigationStack{
        statok()
    }
}
