import SwiftUI

@main
struct HyperrunnersApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
