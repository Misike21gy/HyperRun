import SwiftUI

nonisolated(unsafe) struct UserResponse: Decodable {
    let success: Bool
    let message: String?
}

struct szemelyesadatok: View {
    
    @Binding var username: String
    @AppStorage("username") private var storedUsername: String = ""
    
    @AppStorage("email") private var email: String = ""
    @State private var tempEmail: String = ""
    
    @AppStorage("password") private var password: String = ""
    @State private var currentPassword: String = ""
    
    @State private var fioktorles: Bool = false
    @FocusState private var isTyping: Bool
    @State private var mentve: Bool = false
    
    @AppStorage("profilImageData") private var profilImageData: Data?
    
    func loginUser() {
        print("🔵 Bejelentkezés gomb megnyomva")

        guard let url = URL(string: "http://localhost/Weblap/php/login.php") else {
            print("🔴 Hibás URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: String] = [
            "email": tempEmail,
            "password": currentPassword
        ]

        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { data, response, error in

            if let error {
                print("🔴 Hálózati hiba:", error.localizedDescription)
                return
            }

            guard let data else {
                print("🔴 Nincs adat a válaszban")
                return
            }

            print("🟢 Válasz:", String(data: data, encoding: .utf8) ?? "nil")

            if let decoded = try? JSONDecoder().decode(UserResponse.self, from: data) {
                DispatchQueue.main.async {
                    if decoded.success {
                        if !storedUsername.isEmpty {
                            username = storedUsername
                        }
                        email = tempEmail
                        password = currentPassword
                    } else {
                        print("🔴 Szerver hiba:", decoded.message ?? "nincs üzenet")
                    }
                }
            }

        }.resume()
    }
    
    var body: some View{
        
        
        ZStack {
            Color.clear
                .contentShape(Rectangle())
                .onTapGesture {
                    isTyping = false
                }
            
            VStack(spacing: 8) {
                Text(mentve ? "✅" : (isTyping ? "🫣" : "🙂"))
                    .font(.system(size: 60))
                Text("Személyes adatok")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(.primary)
                    .padding(.bottom, 50)
                
                TextField("felhasználónév", text: $storedUsername)
                    .textFieldStyle(.roundedBorder)
                    .focused($isTyping)
                    .padding(.horizontal)
                    .onChange(of: storedUsername) { newValue in
                        username = newValue
                    }
                    .onAppear { storedUsername = username }
                
                TextField("email", text: $tempEmail)
                    .textFieldStyle(.roundedBorder)
                    .focused($isTyping)
                    .padding(.horizontal)
                    .onAppear { tempEmail = email }
                
                SecureField("jelszó", text: $currentPassword)
                    .textFieldStyle(.roundedBorder)
                    .focused($isTyping)
                    .padding(.horizontal)
                    .padding(.bottom, 50)
                
                Button("Bejelentkezés") {
                    loginUser()
                }
                .buttonStyle(.borderedProminent)
                
                Button("Kijelentkezés", role: .destructive) {
                    fioktorles = true
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .alert("Figyelem", isPresented: $fioktorles) {
                    Button("Mégse", role: .cancel) { }
                    Button("Igen!", role: .destructive) {
                        username = ""
                        storedUsername = ""
                        email = ""
                        tempEmail = ""
                        password = ""
                        currentPassword = ""
                        mentve = false
                        profilImageData = nil
                    }
                } message: {
                    Text("Biztos ki akarsz lépni a fiókodból? \n Ez a művelet nem visszavonható!")
                }
                
                Text("Nincs fiókod?")
                    .font(.system(size: 15))
                    .padding(.top, 50)
                    .foregroundColor(.white)
                Link(destination: URL(string: "https://www.google.com")!) {
                    Label("Regisztrálj most!", systemImage: "globe")
                        .foregroundColor(.white)
                }
                
            }
        }
    }
}

#Preview {
    NavigationStack {
        szemelyesadatok(username: .constant("TesztFelhasználó"))
    }
}

