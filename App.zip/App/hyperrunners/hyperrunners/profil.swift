import PhotosUI
import SwiftUI

struct Profil: View {
    
    @Binding var username: String
    
    @Environment(\.colorScheme) var colorScheme
    @Environment(\.dismiss) private var dismiss
    @State private var selectedItem: PhotosPickerItem?
    
    @AppStorage("profilImageData") private var profilImageData: Data?
    
    private var profilImage: Image? {
        if let data = profilImageData, let uiImage = UIImage(data: data) {
            return Image(uiImage: uiImage)
        }
        return nil
    }
    
    var body: some View {
        Spacer()
        
        VStack(spacing: 12) {
            HStack(spacing: 16) {
                PhotosPicker(selection: $selectedItem, matching: .images) {
                    if let profilImage = profilImage {
                        profilImage
                            .resizable()
                            .scaledToFill()
                            .frame(width: 70, height: 70)
                            .clipShape(Circle())
                            .shadow(radius: 4)
                    } else {
                        Circle()
                            .fill(.gray.opacity(0.3))
                            .frame(width: 70, height: 70)
                            .overlay(
                                Image(systemName: "camera.fill")
                                    .foregroundStyle(.gray)
                                    .font(.system(size: 22))
                            )
                    }
                }
                .onChange(of: selectedItem) { _, newValue in
                    Task {
                        if let data = try? await newValue?.loadTransferable(type: Data.self) {
                            profilImageData = data
                        }
                    }
                }

                Text(username.isEmpty ? "Üdv a profilodban!" :
                     "Üdv a profilodban, \(username)!")
                    .font(.headline)
                    .foregroundStyle(.primary)
                    .foregroundStyle(colorScheme == .dark ? Color(.white) : Color(.black))

                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(colorScheme == .dark ? Color(.darkGray) : Color(.lightGray))
                    .frame(height: 100)
            )
            .padding(.horizontal, 16)
            .padding(.bottom, 24)
            
            VStack(spacing: 16) {
                NavigationLink {
                    szemelyesadatok(username: $username)
                } label: {
                    HStack {
                        Image(systemName: "person.circle")
                            .foregroundStyle(colorScheme == .dark ? Color(.white) : Color(.black))
                        Text("Profil beállítások")
                            .foregroundStyle(colorScheme == .dark ? Color(.white) : Color(.black))
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(colorScheme == .dark ? Color(.darkGray) : Color(.lightGray))
                    .cornerRadius(15)
                }

                NavigationLink {
                    Theme()
                } label: {
                    HStack {
                        Image(systemName: "paintpalette")
                            .foregroundStyle(colorScheme == .dark ? Color(.white) : Color(.black))
                        Text("Téma módosítás")
                            .foregroundStyle(colorScheme == .dark ? Color(.white) : Color(.black))
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(colorScheme == .dark ? Color(.darkGray) : Color(.lightGray))
                    .cornerRadius(15)
                }
                NavigationLink {
                    Visszajelzes()
                } label: {
                    HStack {
                        Image(systemName: "exclamationmark.bubble")
                            .foregroundStyle(colorScheme == .dark ? Color(.white) : Color(.black))
                        Text("Visszajelzés")
                            .foregroundStyle(colorScheme == .dark ? Color(.white) : Color(.black))
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(colorScheme == .dark ? Color(.darkGray) : Color(.lightGray))
                    .cornerRadius(15)
                }

                Spacer()
            }
            .padding()
            
            Text("Az app aktuális verziója: 1.1")
                .font(.system(size: 15))
                .foregroundColor(.secondary)
        }
        .padding()
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    dismiss()
                } label: {
                    Label("Bezárás", systemImage: "xmark")
                }
            }
        }
        .navigationTitle("Profil")
        .navigationBarTitleDisplayMode(.inline)
    }
}
 
#Preview {
    Profil(username: .constant("TesztFelhasználó"))
}
