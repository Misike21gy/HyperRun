import SwiftUI

struct Theme: View {
    
    @AppStorage("themeColor") private var themeColorKey: String = "red"
    @Environment(\.colorScheme) var colorScheme
    
    private func setTheme(_ key: String) {
        themeColorKey = key
    }
    
    var body: some View {
        VStack(spacing: 16) {
            Text("Téma módosítása")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.primary)
                .padding(.bottom, 24)
            
            HStack(spacing: 20){
                Button(action: { setTheme("red") }) {
                    Circle()
                }
                .font(.title3.weight(.semibold))
                .foregroundStyle(.red)
                
                Button(action: { setTheme("yellow") }) {
                    Circle()
                }
                .font(.title3.weight(.semibold))
                .foregroundStyle(.yellow)
                
                Button(action: { setTheme("green") }) {
                    Circle()
                }
                .font(.title3.weight(.semibold))
                .foregroundStyle(.green)
                
                Button(action: { setTheme("purple") }) {
                    Circle()
                }
                .font(.title3.weight(.semibold))
                .foregroundStyle(.purple)
                
                Button(action: { setTheme("blue") }) {
                    Circle()
                }
                .font(.title3.weight(.semibold))
                .foregroundStyle(.blue)
            }
            .background(
                RoundedRectangle(cornerRadius: 35, style: .continuous)
                    .fill(colorScheme == .dark ? Color(.darkGray) : Color(.lightGray))
                    .frame( width: 390, height: 80)
            )
        }
        .padding()
    }
}

#Preview {
    Theme()
}
