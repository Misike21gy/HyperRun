import SwiftUI

struct MainTabView: View {
    private enum TabID: Hashable {
        case kezdolap
        case hirek
    }
    
    @State private var selectedTab: TabID = .kezdolap
    @AppStorage("username") private var taroltUsername: String = ""
    @State private var showProfile: Bool = false
    @Environment(\.colorScheme) var colorScheme
    
    @AppStorage("themeColor") private var themeColorKey: String = "red"
    private var themeColor: Color {
        switch themeColorKey {
        case "green": return .green
        case "yellow": return .yellow
        case "purple": return .purple
        case "blue": return .blue
        default: return .red
        }
    }
    
    var body: some View {
        NavigationStack {
            SwiftUI.TabView(selection: $selectedTab) {
                kezdolap(onOpenProfile: { showProfile = true })
                    .tag(TabID.kezdolap)
                    .tabItem {
                        Label("Kezdőlap", systemImage: "house.fill")
                    }
                
                hirek()
                    .tag(TabID.hirek)
                    .tabItem {
                        Label("Hírek", systemImage: "newspaper.fill")
                    }
            }
            .tint(themeColor)
            .navigationTitle(navigationTitle)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        showProfile = true
                    } label: {
                        Label("Profilod", systemImage: "person.circle.fill")
                    }
                }
            }
            .fullScreenCover(isPresented: $showProfile) {
                NavigationStack {
                    Profil(username: $taroltUsername)
                }
            }
        }
    }
    
    private var navigationTitle: String {
        switch selectedTab {
        case .kezdolap:
            return taroltUsername.isEmpty ? "Üdvözöllek!" : "Üdvözöllek, \(taroltUsername)!"
        case .hirek:
            return taroltUsername.isEmpty ? "Üdvözöllek!" : "Üdvözöllek, \(taroltUsername)!"
        }
    }
}

//MARK: kezdőlap tab
struct kezdolap: View {
    @AppStorage("username") private var taroltUsername: String = ""
    @Environment(\.colorScheme) private var colorScheme
    
    @AppStorage("themeColor") private var themeColorKey: String = "red"
    
    @State private var targetDate: Date = {
        var comp = DateComponents()
        comp.year = 2026
        comp.month = 07
        comp.day = 01
        comp.hour = 01
        comp.minute = 0
        return Calendar.current.date(from: comp) ?? Date()
    }()
    
    @State private var timeRemaining: String = ""
    @State private var showTippek = false
    @State private var showHir = false
    @State private var showEsemeny = false
    @State private var showVisszajelzes = false
    @State private var animateProfilePrompt = false
    @State private var showStats = false
    
    private func updateCountdown() {
        let now = Date()
        let diff = targetDate.timeIntervalSince(now)
        
        if diff <= 0 {
            timeRemaining = ""
        } else {
            let days = Int(diff) / 86400
            let hours = (Int(diff) % 86400) / 3600
            let minutes = (Int(diff) % 3600) / 60
            timeRemaining = "\(days) nap \(hours) óra \(minutes) perc"
        }
    }
    var onOpenProfile: () -> Void = {}
    
    private var themeColor: Color {
        switch themeColorKey {
        case "green": return .green
        case "yellow": return .yellow
        case "purple": return .purple
        case "blue": return .blue
        default: return .red
        }
    }
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [themeColor.opacity(0.8), Color.clear]),
                startPoint: .top,
                endPoint: .bottom
            )
            .frame(maxWidth: .infinity, maxHeight: 680)
            .ignoresSafeArea()
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    if taroltUsername.isEmpty {
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .frame(width: 335, height: 80)
                                .foregroundStyle(themeColor)
                            
                            Button {
                                onOpenProfile()
                            } label: {
                                Text("Hozd létre a profilod 👋")
                                    .foregroundStyle(.white)
                                    .font(.system(size: 25))
                            }
                        }
                        .scaleEffect(animateProfilePrompt ? 1.015 : 1.0)
                        .shadow(color: themeColor.opacity(animateProfilePrompt ? 0.22 : 0.12), radius: animateProfilePrompt ? 14 : 8)
                        .animation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: animateProfilePrompt)
                    }
                    
                    ZStack {
                        RoundedRectangle(cornerRadius: 30)
                            .foregroundStyle(themeColor)
                            .frame(width: 335, height: 235)
                        VStack(alignment: .center, spacing: 0) {
                            Text("Tippek")
                                .foregroundStyle(Color(.white))
                                .underline()
                                .font(.system(size: 22))
                            Text("Tudtad? Biker igazán szeret az élvonalba lenni. \n Légy mindig résen!")
                                .font(.system(size: 18))
                                .foregroundStyle(Color(.white))
                                .multilineTextAlignment(.center)
                                .padding(.top, 4)
                                .padding(.horizontal)
                                .fixedSize(horizontal: false, vertical: true)
                            Image("Biker2")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 120, height: 120)
                                .clipped()
                        }
                    }
                    .offset(y: showTippek ? 0 : 40)
                    .opacity(showTippek ? 1 : 0)
                    
                    ZStack {
                        RoundedRectangle(cornerRadius: 30)
                            .foregroundStyle(themeColor)
                            .frame(width: 335, height: 160)
                        VStack(alignment: .center, spacing: 0) {
                            Text("Hír összefoglaló")
                                .foregroundStyle(Color(.white))
                                .underline()
                                .font(.system(size: 22))
                            Text("Újdonság! Fiókod már nem csak a \n weboldalon, de az appban is \n szerkesztheted. \n Próbáld ki most!")
                                .font(.system(size: 18))
                                .foregroundStyle(Color(.white))
                                .multilineTextAlignment(.center)
                                .padding(.top, 4)
                                .padding(.horizontal)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .offset(y: showHir ? 0 : 40)
                    .opacity(showHir ? 1 : 0)
                    
                    ZStack {
                        RoundedRectangle(cornerRadius: 30)
                            .foregroundStyle(themeColor)
                            .frame(width: 335, height: 120)
                        VStack(alignment: .center, spacing: 0) {
                            Text("Események ☀️⛱️")
                                .foregroundStyle(Color(.white))
                                .underline()
                                .font(.system(size: 22))
                            Text("A nyári pálya megjelnése: \n \(timeRemaining)")
                                .font(.system(size: 20))
                                .foregroundStyle(Color(.white))
                                .multilineTextAlignment(.center)
                                .padding(.top, 4)
                                .padding(.horizontal)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .offset(y: showEsemeny ? 0 : 40)
                    .opacity(showEsemeny ? 1 : 0)
                    
                    Button {
                        showStats = true
                    } label: {
                        ZStack {
                            RoundedRectangle(cornerRadius: 30)
                                .foregroundStyle(themeColor)
                                .frame(width: 335, height: 80)
                            VStack(alignment: .center, spacing: 0) {
                                Text("Statisztikák 📈 \n és rangsor")
                                    .foregroundStyle(Color(.white))
                                    .font(.system(size: 22))
                            }
                        }
                    }
                    .buttonStyle(.plain)
                    .offset(y: showHir ? 0 : 40)
                    .opacity(showHir ? 1 : 0)
                    .sheet(isPresented: $showStats) {
                        statok()
                    }
                }
                .padding(.top, 24)
                .frame(maxWidth: .infinity)
                .padding(.bottom, 24)
            }
        }
        .onAppear {
            updateCountdown()
            animateProfilePrompt = taroltUsername.isEmpty
            Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { _ in
                updateCountdown()
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                withAnimation(.easeOut(duration: 0.5)) { showTippek = true }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                withAnimation(.easeOut(duration: 0.5)) { showHir = true }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                withAnimation(.easeOut(duration: 0.5)) { showEsemeny = true }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                withAnimation(.easeOut(duration: 0.5)) { showVisszajelzes = true }
            }
        }
        .onChange(of: taroltUsername) { _, newValue in
            animateProfilePrompt = newValue.isEmpty
        }
    }
}

//MARK: hírek tab
struct hirek: View {
    @Environment(\.colorScheme) private var colorScheme
    @AppStorage("themeColor") private var themeColorKey: String = "red"
    
    private var themeColor: Color {
        switch themeColorKey {
        case "green": return .green
        case "yellow": return .yellow
        case "purple": return .purple
        case "blue": return .blue
        default: return .red
        }
    }
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [themeColor.opacity(0.8), Color.clear]),
                startPoint: .top,
                endPoint: .bottom
            )
            .frame(maxWidth: .infinity, maxHeight: 680)
            .ignoresSafeArea(edges: .top)
            
            ScrollView {
                VStack {
                    VStack(spacing: 20) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 22)
                                .fill(.ultraThinMaterial)
                                .frame(width: 380, height: 170)
                            VStack(alignment: .center, spacing: 0) {
                                Text("2026.03.31. - Játékunk elkészült. Próbáld ki a HyperRun-t barátiddal akár most! ")
                                    .font(.system(size: 16, weight: .medium))
                                    .multilineTextAlignment(.center)
                                    .lineSpacing(4)
                                    .padding(.top, 12)
                                    .padding(.horizontal)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }

                        ZStack {
                            RoundedRectangle(cornerRadius: 22)
                                .fill(.ultraThinMaterial)
                                .frame(width: 380, height: 170)
                            VStack(alignment: .center, spacing: 0) {
                                Text("2026.01.22. - Folyamatos fejlesztések! \n Örömmel jelentjük ki, hogy a játék demója hamarosan érzekik.")
                                    .font(.system(size: 16, weight: .medium))
                                    .multilineTextAlignment(.center)
                                    .lineSpacing(4)
                                    .padding(.top, 12)
                                    .padding(.horizontal)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }

                        ZStack {
                            RoundedRectangle(cornerRadius: 22)
                                .fill(.ultraThinMaterial)
                                .frame(width: 380, height: 170)
                            VStack(alignment: .center, spacing: 0) {
                                Text("2025.12.16. - Elküszült appunk első bétája, mely elérhető a TestFlight-ban!")
                                    .font(.system(size: 16, weight: .medium))
                                    .multilineTextAlignment(.center)
                                    .lineSpacing(4)
                                    .padding(.top, 12)
                                    .padding(.horizontal)
                                    .fixedSize(horizontal: false, vertical: true)
                                Link(destination: URL(string: "https://developer.apple.com/testflight/")!) {
                                    Label("Bétáért kattints ide", systemImage: "globe")
                                        .foregroundStyle(.white)
                                }
                                .padding(.top, 8)
                            }
                        }

                        ZStack {
                            RoundedRectangle(cornerRadius: 22)
                                .fill(.ultraThinMaterial)
                                .frame(width: 380, height: 170)
                            VStack(alignment: .center, spacing: 0) {
                                Text("2025.11.25. - A játék első bétája elérhető. Keresd fel weboldalunk további infókért.")
                                    .font(.system(size: 16, weight: .medium))
                                    .multilineTextAlignment(.center)
                                    .lineSpacing(4)
                                    .padding(.top, 12)
                                    .padding(.horizontal)
                                    .fixedSize(horizontal: false, vertical: true)
                                Link(destination: URL(string: "https://www.hyperrun.hu")!) {
                                    Label("Kattints!", systemImage: "globe")
                                        .foregroundStyle(.white)
                                }
                                .padding(.top, 8)
                            }
                        }

                        ZStack {
                            RoundedRectangle(cornerRadius: 22)
                                .fill(.ultraThinMaterial)
                                .frame(width: 380, height: 170)
                            VStack(alignment: .center, spacing: 0) {
                                Text("2025.11.04. - Lassan érkezik az első béta \n Játékunk első bétája hamarosan érkezik!")
                                    .font(.system(size: 16, weight: .medium))
                                    .multilineTextAlignment(.center)
                                    .lineSpacing(4)
                                    .padding(.top, 12)
                                    .padding(.horizontal)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                }
                .padding(.vertical)
            }
        }
    }
}

#Preview {
    MainTabView()
}
