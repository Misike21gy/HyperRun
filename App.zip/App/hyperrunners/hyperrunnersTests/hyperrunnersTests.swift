//
//  hyperrunnersTests.swift
//  hyperrunnersTests
//
//  Created by Gyönyörű Mihály on 2025. 10. 01..
//

import Testing
@testable import hyperrunners

struct hyperrunnersTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
